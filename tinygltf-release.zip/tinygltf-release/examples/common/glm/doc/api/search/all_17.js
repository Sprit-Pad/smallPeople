var searchData=
[
  ['zero',['zero',['../a00162.html#ga788f5a421fc0f40a1296ebc094cbaa8a',1,'glm']]]
];
